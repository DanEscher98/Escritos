*Estimada y gentil Amanda:*

Recopilo aquí las notas que redacté en el proceso de editar esta novelita. Me fue un ejercicio grato, laborioso varias veces, cuyo resultado espero sea de tu agrado. En varios puntos modifiqué parrafos y cometí en otros la osadía de reinterpretarlos. Espero estas notas tengan la virtud de ser como diálogo silente.

Con aprecio, Daniel Sánchez

---


### Capitulo 1: Inti
- Simbolismos importantes: 

### Capitulo 12: De vuelta
- Cosas