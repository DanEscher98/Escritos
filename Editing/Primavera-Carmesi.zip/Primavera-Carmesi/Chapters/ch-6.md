\chapter{La ciudad}

El ruido de la carreta, trastabillando en las rocas y el polvillo del camino de desvanecía ya. Cada vez más mientras se alejaba. Entonces Inti tomó el valor de asomarse e inclinándose, tomó las ropas. Se mudó en silencio. Terminando, un rubor se le subió precipitadamente. Porque las prendas si bien modestamente bonitas, estaban impregnadas de un aroma a carne y manzanas añejas. A Inti le abría el apetito y reflexionando sobre su glotonería, se avergonzó. Se encaminó a la ciudad.

Pasando el portón anduvo rato entre las calzadas sin saber a dónde iba. Porque un olor llevaba a otro. Intentando hallar comida, se perdía. Un fuerte olor a tomillo le encaminaba y se sorprendía luego desorientado por el suave incienso que era como brisa del lugar. Ya estaba nervioso, sujetando el sonar de sus tripitas con ambas manos y su resto de orgullo. En eso, vió unas mesas tras unos cristales. Chocó y encontró la puerta. Aturdido, ingresó en aquel recinto. Las luces entibiaban el lugar. Desde la cocina se traspasaban al comedor olores humeantes. Inti miraba y miraba lo que mascaban otros comensales y todo se le antojaba. Buscó una silla queriendo sentarse. Su cara formo un *¿por qué?* cuando unos nudillos con violencia, chocaron contra su piel. Un tipo, de músculos cobrizos y oliente a trigales, le había asestado en la cara un puñetazo. Viendo a su joven victima caer hasta resbalarse por las baldosas se dió por satisfecho y no intentó golpearle más. Sonrió, como rudo campesino. Y se fue.

\- "Qué persona más cruel'' dijo uno.

\- "Nadie comprende a los obreros'' añadió otro, "el calor les aturde''.

Un recién llegado le tendió la mano y le ayudó a pararse. Inti se sacudió los pantalones y tocando sus bolsillos, notó que le faltaba el artefacto. Una mueca le corroyó el rostro. Había pensado en cambiar la bolita azul para afianzar en trueque una comida o un bocado. Dirigió con urgencia hambrienta, sus pasos hacia aquel campesino.
