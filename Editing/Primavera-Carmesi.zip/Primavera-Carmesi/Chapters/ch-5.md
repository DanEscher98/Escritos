\chapter{Después}

En cuanto el oficial dejó de verse, los dos hombre se le acercaron de nuevo. Uno de ellos metió sus manos dentro de sus pantalones grises y holgados, sacando un objeto pequeño y redondo que depositó en las manos de Inti.

\- "No quise mostrárselo al oficial. Ya sabrá usted que él vela por los intereses de la comuna y se crearía ideas'' le dijo el hombre antes de retirarse.

\vspace{1cm}

Inti miro el objeto, lo hizo rodar entre su índice y pulgar. Le pareció tierno. Era de un azul que remembraba a un globo terráqueo y brillante.

\- "*Verdaderamente no es mío*'' pensó mientras lo toqueteaba. Luego se miro a sí mismo. Consideró el maltrato que padecían sus ropas, recordó el bosque. Caminó y se escondió en él. Recostándose sobre la corteza de un cedro se volvió a ocupar de lo bolita azul. La hacia saltar por los aires para volverla a atrapar. La toqueteó un poquito más y notando una mancha la frotó para limpiarla. Se escuchó un leve ruido y emitió algo de luz. Sin embargo Inti no lo notó. El hambre le agobiaba. Pasó otra carreta.

\- "*¿Qué no se dignará a pasar un carro?*'' se dijo Inti para sí, ya exasperado. Se detuvo la carreta y de ella saltó un hombrecito. Con el chal inflamado sobre su barriga, botones de plata y un collar pesado trastabillándole alrededor del cuello. Traía un muda, prendas dobladas en su mano. Rascándose la cabeza caminaba hacia Inti. Dejó la ropa en el pasto fresco y se detuvo como si olvidase algo.

\- "Pedro, ¿se puede saber que haces dejando ropa en el bosque?'' chilló su esposa desde la carreta. "¿Es que los cigarrillos de esa posta te han arruinado la cabeza?''

\- "No lo sé, yo juraría que había alguien allí.''

\- "¿Allí dónde? ¿Qué dices? ¿que hablas? Tú oyes voces, estas loco. Y ni se te ocurra traer esos trapos de vuelta o le diré al cardenal que te han poseído.'' Pedro había hecho ademán de agacharse nuevamente, pero oyendo a su esposa volvió a la carreta. Y batallando, logró subirse poniéndose de nuevo en marcha.
