\chapter{Fantasía}

Fueron muchas cosas de esa aventura. Pero entendió entonces que no había sido el sol. Estaba él como trapito limpio en la arena. Y la arena de otra tierra fue pura maldad. No podía sacarse la idea de aquello que veía en ese momento. Ni la sensación de que su cuerpo le mentía  cuerpo a Dios. Dejando eso atrás se colocó de rodillas y miró donde estaba. Si sería cierto un otro lugar distinto del suyo. Parándose sacudió la arena pegada a su ropa desgarrada. Veía una ciudad cerca. Rica en la vecindad y en los vecinos. Avanzó unos pasos, encontrándose con una carreta y luego otra más. El ruido de las piedrecillas tronando bajo esas ruedas rusticas seguía sonando por todo el camino.

\vspace{1cm}

Uno de esos carretoneros de anchas espaldas y manos ajadas por trabajo y sol se ofreció a llevarlo hasta la ciudad.  Manejaba los caballos, siempre atento a él que iba detrás. Inti traía la levita doblada en los brazos. Sus manos envueltas en guantes recordaban a patitas de oso cuyas puntas se alargaban. Con su camisa, corbata y vestimenta toda confeccionada bajo el fondo de tonalidades cafés. Pues pese a los jirones en su ropa intentaba lucir pulcro, con el azul en sus distraídos ojos. Un poco antes de llegar al portón descendió de la carreta, completaría el resto andando. Inti sintió que la curiosidad le picaba el cuello y luego el cuerpo entero bajo una pregunta recién llegada. Viendo a un hombre, lo siguió hasta darle alcance. Al detenerlo, se percató que era un comandante de la policía. Inti tenía la voz entrecortada por la prisa de haberle alcanzado. Intentando mostrar la buena fe de su carácter como pasaporte de turismo, le preguntó con más inocencia que fineza si ahí o por allí vivía alguien.

\- "Pues naturalmente que vive el señor. Es ridículo que lo pregunte ¿Qué pensaba al lanzarme esa ocurrencia?'' Sin esperar respuesta el hombre se volteo dándole la espalda y siguió caminando.

\- "Pero \dots eh'' decía Inti en su ansiedad por respuestas. "*¿Cómo hacerle saber?*'' y le seguía el paso mientras buscaba palabras. "Espere, que yo \dots yo quería saber si \dots si aquí hay dragones". El hombre en su prisa, exasperado, hacia gestos.
\- "¿Eres niño para preguntar eso?" terminó diciendo.
\- "Lo \dots los hay?"

Fue entonces que el comandante paró y se volvió. Dio unos pasos hasta acercarse. Posando su guante sobre los cabellos revueltos de Inti, dijo esbozando una sonrisa a media voz: "Los hay''. Inti quedó sin conciencia.

