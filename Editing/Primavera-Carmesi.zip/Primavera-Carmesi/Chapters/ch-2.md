\chapter{Oración vana}

\- "*Señor mío*'', rezaba Inti, "*si eres tú quién me lleva, llévame pues lejos de aquí. Que las ondas de la mar son fuertes y aturden mi voluntad. Que las grietas en donde sostengo mi vida me vuelven virutas las manos. No vayas a salvarme solo para azotar mi alma al polvo. Si tu bondad me condena a sentir el hielo de la soledad nuevamente, a atar mi vida en la agonía de eternos naufragios. Déjame.*''

Y sintió Inti el susto de ser dejado, pues el aura a su alrededor le quemaba haciéndolo arder, volviéndolo estrella. Y pensó que era mejor volver al naufragio que ser lanzado al infierno. "*Por favor \dots bueno, lo que decidas.*'' Y caían en un abismo. A saber, la imaginación le hundía. "Si no hay de otra'', dijo irónico, animándose venturoso sólo para arrepentirse al instante.

Pasó el alfabeto de sus memorias. Sonaron las horas con su madre y las horas de las meriendas. Entonces despertó al son del sol.