\chapter{Primicia}

Lo persiguió con el estómago doliente. Al alzanzarlo, el hombre se dió la vuelta. No era la persona. Entonces a Inti también le dió alcance un joven militar que, al haber visto la escena, le había conmovido un poco su desesperación, simpatizado con el muchacho.

\- "Ven'' le dijo. "¿Quieres comer? Puedo invitarte, vamos.'' Volvieron al local, o quizás fueron a otro. A Inti le pareció igual de confortable y bien oliente. Estaban comiendo y ya medio satisfecho alzó la vista de su plato, para agradecer al militar. Lo miraba, más su expresión había cambiado. Ahora lo examinaba con el ceño fruncido, se le quedaba viendo. Y los botones de su uniforme brillaban acusándolo, como si se le sospechara algún delito. Inti pensó en excusarse, pero el militar habló primero.

\- "Pero, ¿es que le conozco? ¿Quién es usted? ¿Por qué esta aquí, delante de mí?'' Iba a disculparse pero el militar volvió a hablar. "Sólo recuerdo una emoción, muy extraña ¿sabe? como un sentimiento de querer ayudarlo. Y luego, me encuentro \dots le encuentro en este sitio, con comida que presumo he pagado yo, más \dots ¿por qué?''

\- "Dispense oficial. Le aseguro que eso que dijo \dots eh ¿puedo irme?''

\- "No, hombre. Tal vez, ha de ser cosa mía. Asuntos, culpa del trabajo, aunque alegaría que usaste algun arte para que yo te olvidara. ¿En dónde está la confianza ciudadana en los hombres de la ley?''

Inti estaba sorprendido, sintió como algo viniendo hacia él. Revisó entonces y ahí estaba el globo terráqueo, la bolita azul. Que se metía en su corazón como si fuera una bola de estambre. La primicia del primer encuentro.
